import qrcode

logo = qrcode.make("https://www.JuanDavidCampolargo.com/")

logo.save("JuanDavidCampolargo_Website_QRCode.png")

